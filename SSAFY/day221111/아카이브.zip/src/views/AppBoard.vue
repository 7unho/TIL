<!-- BoardMain 
     BoardList
     BoardListItem
     BoardWrite
     BoardModify
     BoardDelete
-->
<template>
    <div class="board">
      <router-view></router-view>
    </div>
  </template>
  
  <script>
  // @ is an alias to /src
  
  
  export default {
    name: 'AppBoard',
    components: {
      
    }
  }
  </script>
  